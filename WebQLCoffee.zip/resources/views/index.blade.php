@extends('layouts.app')
@section('content')

    @include('components.banner')
    @include('components.menu-home')
    @include('components.cloud-tea')
    @include('components.blog-home')
@endsection
