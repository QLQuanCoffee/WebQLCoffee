<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Xin chào admin</h2>
        <table class="table table-bordered">
            <tr>
                <td>Quản lý loại sản phẩm</td>
                <td><a href="<?php echo e(route('admin.type.index')); ?>">Loại sản phẩm</a></td>
            </tr>
            <tr>
                <td>Quản lý sản phẩm</td>
                <td><a href="<?php echo e(route('admin.product.index')); ?>">Sản phẩm</a></td>
            </tr>
            <tr>
                <td>Quản lý user</td>
                <td><a href="<?php echo e(route('admin.user.index')); ?>">Account</a></td>
            </tr>
            <tr>
                <td>Quản lý cửa hàng</td>
                <td><a href="<?php echo e(route('admin.shop.index')); ?>">Shop</a></td>
            </tr>
            <tr>
                <td>Quản lý đặt nước</td>
                <td><a href="<?php echo e(route('admin.order.index')); ?>">Order</a></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/home.blade.php ENDPATH**/ ?>