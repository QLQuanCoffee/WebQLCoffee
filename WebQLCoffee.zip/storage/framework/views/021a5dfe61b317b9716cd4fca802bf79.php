<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <h2>Thông tin đơn hàng của: <?php echo e($order->user->name); ?></h2>
        <?php if(!empty($order)): ?>
            <table class="table table-bordered">
                <tr>
                    <td>Email: <?php echo e($order->user->email); ?></td>
                    <td>Ngày đặt: <?php echo e($order->date); ?></td>
                    <td>Tổng tiền: <?php echo e($order->price_format($order->total_price)); ?></td>
                </tr>
            </table>
            <?php if(!empty($orderDetails)): ?>
                <table class="table table-bordered">
                    <tr>
                        <th>Ảnh</th>
                        <th>Tên</th>
                        <th>Topping</th>
                        <th>Số lượng</th>
                        <th>Tổng tiền</th>
                    </tr>
                    <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e(asset('images/products/' . $detail->product->photo . '')); ?>" style="height: 50px" alt="">
                            </td>
                            <td><a href="<?php echo e(route('detail', $detail->id)); ?>"><?php echo e($detail->product->name); ?></a></td>
                            <td><?php echo e($detail->topping); ?></td>
                            <td><?php echo e($detail->quantity); ?></td>
                            <td><?php echo e($detail->price); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php endif; ?>
        <?php endif; ?>
        <a href="<?php echo e(route('admin.order.index')); ?>" class="btn btn-danger">Quay lại trang quản lý đơn hàng</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/order/detail.blade.php ENDPATH**/ ?>