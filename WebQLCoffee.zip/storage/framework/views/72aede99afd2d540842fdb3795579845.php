<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <h2>Quản lý đơn hàng</h2>
        <table class="table table-bordered">
            <tr>
                <th>Email</th>
                <th>Họ Tên</th>
                <th>Ngày đặt</th>
                <th>Tổng tiền</th>
                <th>Chỉnh sửa</th>
            </tr>
            <?php if(!empty($orders)): ?>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.order.detail', $order->id)); ?>"><?php echo e($order->user->email); ?></a></td>
                        <td><?php echo e($order->user->name); ?></td>
                        <td><?php echo e($order->date); ?></td>
                        <td><?php echo e($order->price_format($order->total_price)); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.order.delete', $order->id)); ?>" method="GET"
                                onsubmit="return confirm('<?php echo e(trans('Bạn có muốn xoá order này không ? ')); ?>');"
                                style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <input type="submit" class="btn btn-danger" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>
        <a href="<?php echo e(route('admin.home')); ?>" class="btn btn-danger">Quay lại trang chủ admin</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/order/index.blade.php ENDPATH**/ ?>