<?php $__env->startSection('content'); ?>
    <!-- Main -->
    <div id="main">
        <div class="sidebar">
            <ul>
                <li>
                    <a href="#">Tất Cả</a>
                </li>
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="#<?php echo e($type->id); ?>"><?php echo e($type->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="content">
            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container">
                    <div class="row">
                        <h2 id="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></h2>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->type_id==$type->id): ?>
                                <div class="col-lg-4 col-md-6 col-6">
                                    <a href="<?php echo e(route('detail',$product->id)); ?>"><img src="<?php echo e(asset('images/products/'.$product->photo.'')); ?>" alt=""></a>
                                    <h4><a href="<?php echo e(route('detail',$product->id)); ?>"><?php echo e($product->name); ?></a></h4>
                                    <p><?php echo e($product->price_format($product->price)); ?></p>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/products.blade.php ENDPATH**/ ?>