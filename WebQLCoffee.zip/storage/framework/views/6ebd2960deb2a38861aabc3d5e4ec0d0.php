<div id="menu_home">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12">
                <a href="#">
                    <img src="<?php echo e(asset('images/products/sale.webp')); ?>" alt="">
                </a>
            </div>
            <?php if($products): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 col-6">
                        <a href="<?php echo e(route('detail', $product->id)); ?>">
                            <img src="<?php echo e(asset('images/products/'. $product->photo)); ?>" alt="">
                        </a>
                        <h4>
                            <a href="<?php echo e(route('detail', $product->id)); ?>"><?php echo e($product->name); ?></a>
                        </h4>
                        <p><?php echo e($product->price_format($product->price)); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/components/menu-home.blade.php ENDPATH**/ ?>