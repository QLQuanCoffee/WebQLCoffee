<?php $__env->startSection('content'); ?>
    <div class="container">
        <form method="post" action="<?php echo e(route('admin.user.postInsert')); ?>" enctype="multipart/form-data">
            <div class="login">
                <h2 class="mt-5 mb-3">Tạo mới tài khoản</h2>
                <!-- Name-->
                <input type="text" class="form-control mt-3 " name="name" placeholder="Họ Tên" value="<?php echo e(old('name')); ?>" />
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Email-->
                <input type="email" class="form-control mt-3" name="email" placeholder="Email của bạn" value="<?php echo e(old('email')); ?>" />
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Phone -->
                <input type="text" class="form-control mt-3" name="phone" placeholder="Điện thoại" value="<?php echo e(old('phone')); ?>" />
                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Password-->
                <input type="password" class="form-control mt-3" name="password" placeholder="Nhập mật khẩu" value="<?php echo e(old('password')); ?>" />
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <!-- Address-->
                <input type="text" class="form-control mt-3" name="address" placeholder="Địa chỉ" value="<?php echo e(old('address')); ?>" />
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php echo csrf_field(); ?>

                <div class="action mt-3 mb-4">
                    <button type="submit" class="btn btn-success">Lưu</button>
                    <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-danger">Huỷ</a>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/user/insert.blade.php ENDPATH**/ ?>