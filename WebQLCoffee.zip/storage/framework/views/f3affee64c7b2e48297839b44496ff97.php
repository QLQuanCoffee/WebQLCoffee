<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <a href="<?php echo e(route('admin.topping.insert')); ?>" class="btn btn-primary mb-2">Thêm loại topping mới</a>
        <table class="table table-bordered">
            <tr>
                <th>Tên loại topping</th>
                <th>Giá topping</th>
                <th>Chỉnh sửa</th>
            </tr>
            <?php if(!empty($toppings)): ?>
                <?php $__currentLoopData = $toppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($topping->name); ?></td>
                        <td><?php echo e($topping->price_format($topping->price)); ?></td>
                        <td><a href="<?php echo e(route('admin.topping.update', ['id' => $topping->id])); ?>" class="btn btn-success">Sửa</a> |
                            <form action="<?php echo e(route('admin.topping.delete',$topping->id)); ?>" method="GET"
                                onsubmit="return confirm('<?php echo e(trans('Bạn có muốn xoá topping này không ? ')); ?>');"
                                style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <input type="submit" class="btn btn-danger"
                                    value="Delete">
                            </form>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>
        <a href="<?php echo e(route('admin.home')); ?>" class="btn btn-danger">Quay lại trang chủ admin</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/topping/index.blade.php ENDPATH**/ ?>