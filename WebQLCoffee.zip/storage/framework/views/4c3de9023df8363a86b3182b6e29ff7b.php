<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <div class="row">
            <a href="<?php echo e(route('admin.product.insert')); ?>" class="btn btn-primary mb-2">Thêm sản phẩm</a>
            <?php if(count($products) > 0): ?>
                <table class="table table-bordered">
                    <tr>
                        <th>Ảnh</th>
                        <th>Tên</th>
                        <th>Giá</th>
                        <th>Loại</th>
                        <th>Chỉnh sửa</th>
                    </tr>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e(asset('images/products/'.$product->photo.'')); ?>" style="width: 100px"
                                    alt="">
                            </td>
                            <td><a href="<?php echo e(route('admin.product.detail', $product->id)); ?>"><?php echo e($product->name); ?></a></td>
                            <td><?php echo e($product->price_format($product->price)); ?></td>
                            <td><?php echo e($product->type->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.product.update', ['id' => $product->id])); ?>"
                                    class="btn btn-success">Sửa</a> |
                                <form action="<?php echo e(route('admin.product.delete', $product->id)); ?>" method="GET"
                                    onsubmit="return confirm('<?php echo e(trans('Bạn có muốn xoá product này không ? ')); ?>');"
                                    style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <input type="submit" class="btn btn-danger" value="Delete">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.home')); ?>" class="btn btn-danger">Quay lại trang chủ admin</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/product/index.blade.php ENDPATH**/ ?>