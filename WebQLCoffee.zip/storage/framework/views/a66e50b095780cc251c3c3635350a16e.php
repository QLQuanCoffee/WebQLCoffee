<div id="cloud_tea">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-12">
                <img src="<?php echo e(asset('images/blog/cloudtea.webp')); ?>" alt="">
            </div>
            <div class="col-lg-6 col-md-12 col-12">
                <img src="<?php echo e(asset('images/blog/tagline.webp')); ?>" alt="">
                <p>
                    Bộ sưu tập “Cầu Toàn Kèo Thơm” không chỉ là thức uống chăm da giữ dáng, mà còn là “vía may mắn” để năm mới thêm trọn vẹn. Với nền trà tốt cho sức khoẻ cùng hương vị mãng cầu và thơm giúp giải ngấy, topping đầy đặn, “Cầu Toàn Kèo Thơm” mang ý nghĩa sung túc cho năm 2023. Chiếc ly mèo đáng yêu còn như một lời chúc may mắn Nhà gửi đến bạn.
                </p>
                <div class="button">
                    <a href="">
                        Thử ngay
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/components/cloud-tea.blade.php ENDPATH**/ ?>