<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <a href="<?php echo e(route('admin.shop.insert')); ?>" class="btn btn-primary mb-2">Thêm sản phẩm</a>
        <div class="row">
            <?php if(count($shops) > 0): ?>
                <table class="table table-bordered">
                    <tr>
                        <th>Ảnh</th>
                        <th>Tên</th>
                        <th>Thời gian</th>
                        <th>Địa chỉ</th>
                        <th>Chỉnh sửa</th>
                    </tr>
                    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <img src="<?php echo e(asset('images/shops/' . $shop->photo . '')); ?>" style="height: 50px" alt="">
                            </td>
                            <td><a href="<?php echo e(route('admin.shop.detail', $shop->id)); ?>"><?php echo e($shop->name); ?></a></td>
                            <td><?php echo e($shop->time); ?></td>
                            <td><?php echo e($shop->address); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.shop.update', ['id' => $shop->id])); ?>"
                                    class="btn btn-success">Sửa</a>
                                <form action="<?php echo e(route('admin.shop.delete', $shop->id)); ?>" method="GET"
                                    onsubmit="return confirm('<?php echo e(trans('Bạn có muốn xoá shop này không ? ')); ?>');"
                                    style="display: inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <input type="submit" class="btn btn-danger" value="Delete">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/shop/index.blade.php ENDPATH**/ ?>