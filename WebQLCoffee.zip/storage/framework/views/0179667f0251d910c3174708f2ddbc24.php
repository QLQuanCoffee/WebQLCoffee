<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <h2>Thông tin user</h2>
        <?php if(!empty($user)): ?>
            <table class="table table-bordered">

                <tr>
                    <td>Họ tên</td>
                    <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                    <td>Điện thoại</td>
                    <td><?php echo e($user->phone); ?></td>
                </tr>
                <tr>
                    <td>Địa chỉ</td>
                    <td><?php echo e($user->address); ?></td>
                </tr>
            </table>
        <?php endif; ?>
        <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-danger">Quay lại trang user</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/user/detail.blade.php ENDPATH**/ ?>