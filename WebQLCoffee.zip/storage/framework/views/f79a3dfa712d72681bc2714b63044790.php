<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <h2>Chỉnh sửa loại sản phẩm</h2>
        <form method="post" action="<?php echo e(route('admin.topping.postUpdate')); ?>" enctype="multipart/form-data">
            <table class="table table-bordered">
                <tr>
                    <td><label class="form-label">Tên Topping</label></td>
                    <td>
                        <input type="hidden" name="id" value="<?php echo e($topping->id); ?>">
                        <input type="text" value="<?php echo e(old('name') ?? $topping->name); ?>" class="form-control"
                            placeholder="Tên Loại" name="name" />
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
                <tr>
                    <td><label class="form-label">Giá</label></td>
                    <td>
                        <input type="text" value="<?php echo e(old('price') ?? $topping->price); ?>" class="form-control"
                            placeholder="Giá topping" name="price" />
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </td>
                </tr>
            </table>
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary">Sửa</button>
            <a href="<?php echo e(route('admin.type.index')); ?>" class="btn btn-danger">Huỷ</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/topping/update.blade.php ENDPATH**/ ?>