<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <h2>Thông tin sản phẩm</h2>
        <?php if(!empty($product)): ?>
            <table class="table table-bordered">
                <tr>
                    <td>Ảnh sản phẩm</td>
                    <td>
                        <img src="<?php echo e(asset('images/products/' . $product->photo . '')); ?>" style="height: 200px" alt="">
                    </td>
                </tr>
                <tr>
                    <td>Tên sản phẩm</td>
                    <td><?php echo e($product->name); ?></td>
                </tr>
                <tr>
                    <td>Giá</td>
                    <td><?php echo e($product->price_format($product->price)); ?></td>
                </tr>
                <tr>
                    <td>Thông tin chi tiết</td>
                    <td><?php echo e($product->description); ?></td>
                </tr>
                <tr>
                    <td>Loại sản phẩm</td>
                    <td><?php echo e($product->type->name); ?></td>
                </tr>
            </table>

            <?php if(count($detailToppings)>0): ?>
                <table class="table table-bordered">
                    <tr>
                        <th>Tên loại topping</th>
                        <th>Giá topping</th>
                    </tr>
                    <?php $__currentLoopData = $detailToppings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($topping->topping->name); ?></td>
                            <td><?php echo e($topping->topping->price_format($topping->topping->price)); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <?php endif; ?>
        <?php endif; ?>
        <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-danger">Quay lại trang quản lý sản phẩm</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/product/detail.blade.php ENDPATH**/ ?>