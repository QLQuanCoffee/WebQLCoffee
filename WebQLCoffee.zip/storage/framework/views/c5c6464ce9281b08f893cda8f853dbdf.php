<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <a href="<?php echo e(route('admin.user.insert')); ?>" class="btn btn-primary mb-2">Thêm tài khoản mới</a>
        <table class="table table-bordered">
            <tr>
                <th>Tài khoản</th>
                <th>Họ Tên</th>
                <th>Chỉnh sửa</th>
            </tr>
            <?php if(!empty($users)): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('admin.user.detail', $user->id)); ?>"><?php echo e($user->email); ?></a></td>
                        <td><?php echo e($user->name); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.user.update', $user->id)); ?>"
                                class="btn btn-success">Sửa</a>
                            <form action="<?php echo e(route('admin.user.delete', $user->id)); ?>" method="GET"
                                onsubmit="return confirm('<?php echo e(trans('Bạn có muốn xoá user này không ? ')); ?>');"
                                style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <input type="submit" class="btn btn-danger" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </table>
        <a href="<?php echo e(route('admin.home')); ?>" class="btn btn-danger">Quay lại trang chủ admin</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/user/index.blade.php ENDPATH**/ ?>