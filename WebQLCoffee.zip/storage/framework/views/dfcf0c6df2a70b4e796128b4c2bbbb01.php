<?php $__env->startSection('content'); ?>
    <div class="container mt-5 mb-5">
        <h2>Thông tin cửa hàng</h2>
        <?php if(!empty($shop)): ?>
            <table class="table table-bordered">
                <tr>
                    <td>Ảnh cửa hàng</td>
                    <td>
                        <img src="<?php echo e(asset('images/shops/' . $shop->photo . '')); ?>" style="height: 200px" alt="">
                    </td>
                </tr>
                <tr>
                    <td>Tên cửa hàng</td>
                    <td><?php echo e($shop->name); ?></td>
                </tr>
                <tr>
                    <td>Địa chỉ</td>
                    <td><?php echo e($shop->address); ?></td>
                </tr>
                <tr>
                    <td>Thông tin chi tiết</td>
                    <td><?php echo e($shop->description); ?></td>
                </tr>
                <tr>
                    <td>Thời gian hoạt động</td>
                    <td><?php echo e($shop->time); ?></td>
                </tr>
            </table>
        <?php endif; ?>
        <a href="<?php echo e(route('admin.shop.index')); ?>" class="btn btn-danger">Quay lại trang quản lý cửa hàng</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\Laravel\WebQLCoffee\resources\views/admin/shop/detail.blade.php ENDPATH**/ ?>